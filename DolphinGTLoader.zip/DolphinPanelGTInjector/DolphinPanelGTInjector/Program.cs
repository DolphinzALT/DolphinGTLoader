﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;

class Program
{
    const string VALID_KEY = "A1B2C3";
    const string DLL_URL = "https://github.com/DolphinzALT/DolphinGTLite/raw/refs/heads/main/StupidTemplate.dll";
    const string DLL_NAME = "StupidTemplate.dll";
    static string GamePath = @"C:\Program Files (x86)\Steam\steamapps\common\Gorilla Tag";
    static string ExePath = Path.Combine(GamePath, "Gorilla Tag.exe");
    static string PluginsPath = Path.Combine(GamePath, @"BepInEx\plugins");
    static string DllDestination = Path.Combine(PluginsPath, DLL_NAME);

    [DllImport("kernel32.dll")] static extern bool FreeConsole();

    static bool injected = false;

    [STAThread]
    static void Main()
    {
        Console.Title = "DolphinPanelGT Loader";

        Banner("DolphinPanelGT", ConsoleColor.Magenta);

        if (!IsAdmin())
        {
            Red("[x] Run as administrator.");
            Console.ReadKey();
            return;
        }

        White(">> Enter key: ");
        Console.ForegroundColor = ConsoleColor.Cyan;
        if (Console.ReadLine()?.Trim() != VALID_KEY)
        {
            Red("[x] Invalid key.");
            Thread.Sleep(1500);
            return;
        }

        Console.ResetColor();
        Console.WriteLine("\n[1] Inject Cheat");
        Console.WriteLine("[2] Remove Cheat");
        Console.WriteLine("[3] Exit");
        White(">> Choose an option: ");

        string option = Console.ReadLine()?.Trim();

        switch (option)
        {
            case "1": Inject(); break;
            case "2": ManualCleanup(); break;
            default: Environment.Exit(0); break;
        }
    }

    static void Inject()
    {
        if (!Directory.Exists(PluginsPath))
        {
            Red("[x] Gorilla Tag BepInEx not found.");
            return;
        }

        if (IsGameRunning())
        {
            Yellow(">> Gorilla Tag is running.");
            White(">> Restart to inject? (y/n): ");
            string input = Console.ReadLine()?.Trim().ToLower();
            if (input != "y" && input != "yes")
            {
                Red("[x] Injection cancelled.");
                return;
            }

            KillGame();
            Thread.Sleep(1000);
        }

        White(">> Downloading...");
        try
        {
            using (var wc = new WebClient())
            {
                wc.Headers.Add("User-Agent", "Mozilla/5.0");
                wc.DownloadFile(DLL_URL, DllDestination);
            }

            File.SetAttributes(DllDestination, FileAttributes.Hidden | FileAttributes.System);
            Green("[+] Cheat loaded.");
            injected = true;
        }
        catch (Exception ex)
        {
            Red("[x] Download failed: " + ex.Message);
            return;
        }

        White(">> Launching Gorilla Tag...");
        try { Process.Start(ExePath); }
        catch { Red("[x] Failed to start game."); return; }

        Thread.Sleep(2000);
        FreeConsole(); // ✅ Cleanly removes the console without crashing

        Process gtag = WaitForGorillaTag();
        if (gtag != null)
        {
            gtag.WaitForExit();
            Thread.Sleep(3000);
            if (injected) SafeCleanup();
        }
    }

    static void ManualCleanup()
    {
        try
        {
            if (File.Exists(DllDestination))
            {
                File.SetAttributes(DllDestination, FileAttributes.Normal);
                File.Delete(DllDestination);
                Green("[+] Cheat removed.");
            }
            else
            {
                Yellow("[!] DLL already removed or not found.");
            }
        }
        catch (Exception ex)
        {
            Red("[x] Error removing DLL: " + ex.Message);
        }

        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
        Environment.Exit(0);
    }

    static void SafeCleanup()
    {
        try
        {
            if (File.Exists(DllDestination))
            {
                File.SetAttributes(DllDestination, FileAttributes.Normal);
                File.Delete(DllDestination);
                Green("[+] Cheat auto-removed.");
            }
        }
        catch (Exception ex)
        {
            Red("[x] Cleanup error: " + ex.Message);
        }

        Environment.Exit(0);
    }

    static Process WaitForGorillaTag()
    {
        for (int i = 0; i < 60; i++)
        {
            var procs = Process.GetProcessesByName("Gorilla Tag");
            if (procs.Length > 0)
                return procs[0];

            Thread.Sleep(1500);
        }
        return null;
    }

    static bool IsGameRunning()
    {
        return Process.GetProcessesByName("Gorilla Tag").Length > 0;
    }

    static void KillGame()
    {
        foreach (var p in Process.GetProcessesByName("Gorilla Tag"))
            try { p.Kill(); } catch { }
    }

    static bool IsAdmin()
    {
        var id = System.Security.Principal.WindowsIdentity.GetCurrent();
        var principal = new System.Security.Principal.WindowsPrincipal(id);
        return principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
    }

    // Styled text
    static void Green(string text) { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine(text); Console.ResetColor(); }
    static void Red(string text) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine(text); Console.ResetColor(); }
    static void Yellow(string text) { Console.ForegroundColor = ConsoleColor.Yellow; Console.WriteLine(text); Console.ResetColor(); }
    static void White(string text) { Console.ForegroundColor = ConsoleColor.White; Console.Write(text); Console.ResetColor(); }

    static void Banner(string title, ConsoleColor color)
    {
        Console.ForegroundColor = color;
        Console.WriteLine("╔═══════════════════════════════╗");
        Console.WriteLine($"║    {title.PadLeft((title.Length + 27) / 2).PadRight(27)}║");
        Console.WriteLine("╚═══════════════════════════════╝");
        Console.ResetColor();
    }
}
